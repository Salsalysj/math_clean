import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CollectionScreen extends StatefulWidget {
  const CollectionScreen({Key? key}) : super(key: key);

  @override
  State<CollectionScreen> createState() => _CollectionScreenState();
}

class _CollectionScreenState extends State<CollectionScreen> {
  List<String> collectedCharacters = [];
  
  // 전체 캐릭터 목록
  final List<String> allCharacters = [
    'brainrot_image/가라마라라마라라만 단 마두둥둥 탁 툰퉁 퍼르쿤퉁.webp',
    'brainrot_image/고릴로 워터멜론드릴로.webp',
    'brainrot_image/그라이푸시 메두시.webp',
    'brainrot_image/글로르보 프루토드릴로.webp',
    'brainrot_image/라 바카 사투르노 사투르니타.webp',
    'brainrot_image/리노 토스트리노.webp',
    'brainrot_image/리릴리 라릴라.webp',
    'brainrot_image/마카키니 바나니니.webp',
    'brainrot_image/바나니타 돌피니타.webp',
    'brainrot_image/발레리나 카푸치나.webp',
    'brainrot_image/발레리노 로로로.webp',
    'brainrot_image/보네카 암발라부.webp',
    'brainrot_image/보브리토 반디토.webp',
    'brainrot_image/봄바르디로 크로코딜로.webp',
    'brainrot_image/봄봄비니 구지니.webp',
    'brainrot_image/부르발로니 룰릴롤리.webp',
    'brainrot_image/브르르 브르르 파타핌.webp',
    'brainrot_image/브리 브리 비쿠스 디쿠스 봄비쿠스.webp',
    'brainrot_image/블루베리니 옥토푸시니.webp',
    'brainrot_image/오 딘딘딘딘 둔 마 딘딘딘 둔.webp',
    'brainrot_image/오랑구티니 아나나시니.webp',
    'brainrot_image/일 칵토 히포포타모.webp',
    'brainrot_image/지라파 첼레스테.webp',
    'brainrot_image/지브라 주브라 지브라리니.webp',
    'brainrot_image/침판지니 바나니니.webp',
    'brainrot_image/카푸치노 아사시노.webp',
    'brainrot_image/코코판토 엘레판토.webp',
    'brainrot_image/크로코딜도 페니시니.webp',
    'brainrot_image/타 타 타 타 타 타 타 타 타 타 타 사후르.webp',
    'brainrot_image/퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 사후르.webp',
    'brainrot_image/트랄랄레로 트랄랄라.webp',
    'brainrot_image/트래코투코툴루 델라펠라두스투즈.webp',
    'brainrot_image/트룰리메로 트룰리치나.webp',
    'brainrot_image/트리피 트로피1.webp',
    'brainrot_image/트리피 트로피2.webp',
    'brainrot_image/트릭 트랙 바라붐.webp',
    'brainrot_image/티그룰리 그레이프루투니.webp',
    'brainrot_image/티그룰리니 워터멜리니.webp',
    'brainrot_image/팟 핫스팟.webp',
    'brainrot_image/프룰리 프룰라.webp',
    'brainrot_image/프리고 카멜로.webp',
  ];

  @override
  void initState() {
    super.initState();
    loadCollectedCharacters();
  }

  Future<void> loadCollectedCharacters() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      collectedCharacters = prefs.getStringList('collected_characters') ?? [];
    });
  }

  String getCharacterName(String imagePath) {
    return imagePath
        .split('/')
        .last
        .replaceAll('.webp', '')
        .replaceAll('brainrot_image/', '');
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[50],
      appBar: AppBar(
        title: const Text('캐릭터 도감'),
        backgroundColor: Colors.indigo[600],
        foregroundColor: Colors.white,
        actions: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Center(
              child: Text(
                '${collectedCharacters.length}/${allCharacters.length}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // 진행률 표시
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      '수집 진행률',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Colors.indigo[800],
                      ),
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: collectedCharacters.length / allCharacters.length,
                      backgroundColor: Colors.grey[300],
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.indigo[600]!),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${(collectedCharacters.length / allCharacters.length * 100).toStringAsFixed(1)}% 완료',
                      style: TextStyle(
                        color: Colors.indigo[600],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 20),
              
              // 캐릭터 그리드
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: allCharacters.length,
                  itemBuilder: (context, index) {
                    final character = allCharacters[index];
                    final isCollected = collectedCharacters.contains(character);
                    final characterName = getCharacterName(character);
                    
                    return GestureDetector(
                      onTap: isCollected ? () {
                        showDialog(
                          context: context,
                          builder: (context) => Dialog(
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    characterName,
                                    style: Theme.of(context).textTheme.displayMedium?.copyWith(
                                      color: Colors.indigo[800],
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  const SizedBox(height: 20),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Image.asset(
                                      character,
                                      width: 250,
                                      height: 250,
                                      fit: BoxFit.cover,
                                      errorBuilder: (context, error, stackTrace) {
                                        return Container(
                                          width: 250,
                                          height: 250,
                                          color: Colors.grey[300],
                                          child: Icon(
                                            Icons.image_not_supported,
                                            size: 50,
                                            color: Colors.grey[600],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  ElevatedButton(
                                    onPressed: () => Navigator.pop(context),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.indigo,
                                      foregroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                    ),
                                    child: const Text('닫기'),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      } : null,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3),
                              spreadRadius: 1,
                              blurRadius: 3,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(12),
                                ),
                                child: isCollected
                                    ? Image.asset(
                                        character,
                                        fit: BoxFit.cover,
                                        width: double.infinity,
                                        errorBuilder: (context, error, stackTrace) {
                                          return Container(
                                            color: Colors.grey[300],
                                            child: Icon(
                                              Icons.image_not_supported,
                                              color: Colors.grey[600],
                                            ),
                                          );
                                        },
                                      )
                                    : Container(
                                        color: Colors.grey[400],
                                        child: Icon(
                                          Icons.help_outline,
                                          size: 40,
                                          color: Colors.grey[600],
                                        ),
                                      ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.all(8),
                              child: Text(
                                isCollected ? characterName : '???',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: isCollected ? Colors.indigo[800] : Colors.grey[600],
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 