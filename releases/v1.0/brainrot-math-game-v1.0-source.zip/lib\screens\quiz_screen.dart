import 'package:flutter/material.dart';
import 'dart:math';
import 'reward_screen.dart';

class QuizScreen extends StatefulWidget {
  final VoidCallback? onRefundKey;
  
  const QuizScreen({Key? key, this.onRefundKey}) : super(key: key);

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int currentQuestion = 1;
  int score = 0;
  int? num1, num2, num3, correctAnswer;
  String operation = '+';
  String? operation2;
  bool isThreeTermQuestion = false;
  final TextEditingController _answerController = TextEditingController();
  bool isAnswered = false;
  bool isCorrect = false;
  
  @override
  void initState() {
    super.initState();
    generateQuestion();
  }

  void generateQuestion() {
    if (currentQuestion == 9 || currentQuestion == 10) {
      // 9, 10번째 문제만 3항 혼합 문제
      _generateThreeTermQuestion();
    } else {
      // 1-8번째 문제는 2항 문제
      _generateTwoTermQuestion();
    }
    
    _answerController.clear();
    isAnswered = false;
    isCorrect = false;
  }

  void _generateTwoTermQuestion() {
    final random = Random();
    isThreeTermQuestion = false;
    
    // 연산 종류 선택 (덧셈, 뺄셈, 곱셈)
    final operations = ['+', '-', '×'];
    operation = operations[random.nextInt(operations.length)];
    
    switch (operation) {
      case '+':
        num1 = random.nextInt(90) + 10; // 10~99
        num2 = random.nextInt(90) + 10; // 10~99
        correctAnswer = num1! + num2!;
        break;
      case '-':
        num1 = random.nextInt(90) + 10; // 10~99
        num2 = random.nextInt(num1! - 9) + 10; // 10~(num1-1), 결과가 양수가 되도록
        correctAnswer = num1! - num2!;
        break;
      case '×':
        num1 = random.nextInt(8) + 2; // 2~9 (1 제외)
        num2 = random.nextInt(8) + 2; // 2~9 (1 제외)
        correctAnswer = num1! * num2!;
        break;
    }
  }

  void _generateThreeTermQuestion() {
    final random = Random();
    isThreeTermQuestion = true;
    
    // 첫 번째와 두 번째 연산 선택
    final operations = ['+', '-'];
    operation = operations[random.nextInt(operations.length)];
    operation2 = operations[random.nextInt(operations.length)];
    
    // 한자릿수 생성 (1~9)
    num1 = random.nextInt(9) + 1; // 1~9
    num2 = random.nextInt(9) + 1; // 1~9
    num3 = random.nextInt(9) + 1; // 1~9
    
    // 중간 결과 계산
    int intermediateResult;
    if (operation == '+') {
      intermediateResult = num1! + num2!;
    } else {
      // 뺄셈에서 음수가 나오지 않도록 더 큰 수에서 작은 수를 빼도록 조정
      if (num1! < num2!) {
        final temp = num1;
        num1 = num2;
        num2 = temp;
      }
      intermediateResult = num1! - num2!;
    }
    
    // 최종 결과 계산
    if (operation2 == '+') {
      correctAnswer = intermediateResult + num3!;
    } else {
      // 뺄셈일 때 음수가 나오지 않도록 조정
      if (intermediateResult < num3!) {
        operation2 = '+';
        correctAnswer = intermediateResult + num3!;
      } else {
        correctAnswer = intermediateResult - num3!;
      }
    }
  }

  void checkAnswer() {
    if (_answerController.text.isEmpty) return;
    
    final userAnswer = int.tryParse(_answerController.text);
    if (userAnswer == null) return;
    
    setState(() {
      isAnswered = true;
      isCorrect = userAnswer == correctAnswer;
      if (isCorrect) {
        score++;
      }
    });
  }

  void nextQuestion() {
    if (currentQuestion >= 10) {
      // 10문제 완료 - 보상 화면으로 이동
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => RewardScreen(
            score: score, 
            onRefundKey: score < 8 ? widget.onRefundKey : null,
          ),
        ),
      );
    } else {
      setState(() {
        currentQuestion++;
        generateQuestion();
      });
    }
  }

  String getQuestionText() {
    if (isThreeTermQuestion) {
      return '$num1 $operation $num2 $operation2 $num3 = ?';
    } else {
      return '$num1 $operation $num2 = ?';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        title: Text('문제 $currentQuestion/10'),
        backgroundColor: Colors.purple[600],
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // 점수 표시
              Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.star, color: Colors.amber, size: 30),
                    const SizedBox(width: 10),
                    Text(
                      '점수: $score',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: Colors.purple[800],
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 50),
              
              // 문제 표시
              Container(
                padding: const EdgeInsets.all(30),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      getQuestionText(),
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: Colors.purple[800],
                        fontSize: isThreeTermQuestion ? 32 : 40,
                      ),
                    ),
                    
                    const SizedBox(height: 30),
                    
                    // 답 입력 필드
                    TextField(
                      controller: _answerController,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 24),
                      decoration: InputDecoration(
                        hintText: '답을 입력하세요',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                      ),
                      enabled: !isAnswered,
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // 정답 확인 결과
                    if (isAnswered) ...[
                      Container(
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: isCorrect ? Colors.green[100] : Colors.red[100],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          isCorrect ? '정답입니다! 🎉' : '틀렸습니다. 정답은 $correctAnswer입니다.',
                          style: TextStyle(
                            fontSize: 18,
                            color: isCorrect ? Colors.green[800] : Colors.red[800],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              
              const SizedBox(height: 40),
              
              // 버튼들
              if (!isAnswered) ...[
                ElevatedButton(
                  onPressed: checkAnswer,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: Text(
                    '확인',
                    style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      color: Colors.white,
                    ),
                  ),
                ),
              ] else ...[
                ElevatedButton(
                  onPressed: nextQuestion,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: Text(
                    currentQuestion >= 10 ? '결과 보기' : '다음 문제',
                    style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _answerController.dispose();
    super.dispose();
  }
} 