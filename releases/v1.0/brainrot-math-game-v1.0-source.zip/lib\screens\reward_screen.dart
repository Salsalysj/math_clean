import 'package:flutter/material.dart';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'home_screen.dart';
import 'collection_screen.dart';

class RewardScreen extends StatefulWidget {
  final int score;
  final VoidCallback? onRefundKey;
  
  const RewardScreen({Key? key, required this.score, this.onRefundKey}) : super(key: key);

  @override
  State<RewardScreen> createState() => _RewardScreenState();
}

class _RewardScreenState extends State<RewardScreen> {
  String selectedImage = '';
  bool hasEarnedCharacter = false;
  
  // brainrot_image 폴더의 이미지 파일들
  final List<String> rewardImages = [
    'brainrot_image/가라마라라마라라만 단 마두둥둥 탁 툰퉁 퍼르쿤퉁.webp',
    'brainrot_image/고릴로 워터멜론드릴로.webp',
    'brainrot_image/그라이푸시 메두시.webp',
    'brainrot_image/글로르보 프루토드릴로.webp',
    'brainrot_image/라 바카 사투르노 사투르니타.webp',
    'brainrot_image/리노 토스트리노.webp',
    'brainrot_image/리릴리 라릴라.webp',
    'brainrot_image/마카키니 바나니니.webp',
    'brainrot_image/바나니타 돌피니타.webp',
    'brainrot_image/발레리나 카푸치나.webp',
    'brainrot_image/발레리노 로로로.webp',
    'brainrot_image/보네카 암발라부.webp',
    'brainrot_image/보브리토 반디토.webp',
    'brainrot_image/봄바르디로 크로코딜로.webp',
    'brainrot_image/봄봄비니 구지니.webp',
    'brainrot_image/부르발로니 룰릴롤리.webp',
    'brainrot_image/브르르 브르르 파타핌.webp',
    'brainrot_image/브리 브리 비쿠스 디쿠스 봄비쿠스.webp',
    'brainrot_image/블루베리니 옥토푸시니.webp',
    'brainrot_image/오 딘딘딘딘 둔 마 딘딘딘 둔.webp',
    'brainrot_image/오랑구티니 아나나시니.webp',
    'brainrot_image/일 칵토 히포포타모.webp',
    'brainrot_image/지라파 첼레스테.webp',
    'brainrot_image/지브라 주브라 지브라리니.webp',
    'brainrot_image/침판지니 바나니니.webp',
    'brainrot_image/카푸치노 아사시노.webp',
    'brainrot_image/코코판토 엘레판토.webp',
    'brainrot_image/크로코딜도 페니시니.webp',
    'brainrot_image/타 타 타 타 타 타 타 타 타 타 타 사후르.webp',
    'brainrot_image/퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 사후르.webp',
    'brainrot_image/트랄랄레로 트랄랄라.webp',
    'brainrot_image/트래코투코툴루 델라펠라두스투즈.webp',
    'brainrot_image/트룰리메로 트룰리치나.webp',
    'brainrot_image/트리피 트로피1.webp',
    'brainrot_image/트리피 트로피2.webp',
    'brainrot_image/트릭 트랙 바라붐.webp',
    'brainrot_image/티그룰리 그레이프루투니.webp',
    'brainrot_image/티그룰리니 워터멜리니.webp',
    'brainrot_image/팟 핫스팟.webp',
    'brainrot_image/프룰리 프룰라.webp',
    'brainrot_image/프리고 카멜로.webp',
  ];

  @override
  void initState() {
    super.initState();
    hasEarnedCharacter = widget.score >= 8;
    if (hasEarnedCharacter) {
      selectRandomImage();
      saveCharacterToCollection();
    } else {
      // 8점 미만일 때 열쇠 반환
      widget.onRefundKey?.call();
    }
  }

  void selectRandomImage() {
    final random = Random();
    setState(() {
      selectedImage = rewardImages[random.nextInt(rewardImages.length)];
    });
  }

  Future<void> saveCharacterToCollection() async {
    if (selectedImage.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      List<String> collectedCharacters = prefs.getStringList('collected_characters') ?? [];
      
      if (!collectedCharacters.contains(selectedImage)) {
        collectedCharacters.add(selectedImage);
        await prefs.setStringList('collected_characters', collectedCharacters);
      }
    }
  }

  String getCharacterName(String imagePath) {
    return imagePath
        .split('/')
        .last
        .replaceAll('.webp', '')
        .replaceAll('brainrot_image/', '');
  }



  String getGradeText() {
    if (widget.score == 10) {
      return '완벽해요! 🌟';
    } else if (widget.score >= 8) {
      return '훌륭해요! 🎉';
    } else if (widget.score >= 6) {
      return '잘했어요! 👏';
    } else if (widget.score >= 4) {
      return '좋아요! 😊';
    } else {
      return '다시 도전해봐요! 💪';
    }
  }

  Color getGradeColor() {
    if (widget.score == 10) {
      return Colors.amber;
    } else if (widget.score >= 8) {
      return Colors.green;
    } else if (widget.score >= 6) {
      return Colors.blue;
    } else if (widget.score >= 4) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }

  Widget _buildDefaultRewardImage() {
    return Container(
      width: 300,
      height: 300,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.emoji_events,
            size: 80,
            color: Colors.amber[600],
          ),
          const SizedBox(height: 10),
          Text(
            '축하합니다!',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // 축하 메시지
              Container(
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      '게임 완료!',
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: Colors.pink[800],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '점수: ${widget.score}/10',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: getGradeColor(),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      getGradeText(),
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: getGradeColor(),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // 보상 영역
              Container(
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      hasEarnedCharacter ? '새로운 캐릭터 획득!' : '캐릭터 획득 실패',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: hasEarnedCharacter ? Colors.amber[800] : Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 15),
                    
                    if (hasEarnedCharacter && selectedImage.isNotEmpty) ...[
                      // 캐릭터 이름
                      Text(
                        getCharacterName(selectedImage),
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.pink[800],
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 15),
                      
                      // 캐릭터 이미지
                      ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Image.asset(
                          selectedImage,
                          width: 300,
                          height: 300,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return _buildDefaultRewardImage();
                          },
                        ),
                      ),
                      

                    ] else ...[
                      // 캐릭터 획득 실패 시
                      Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(
                            color: Colors.grey[400]!,
                            style: BorderStyle.solid,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.lock,
                              size: 80,
                              color: Colors.grey[600],
                            ),
                            const SizedBox(height: 20),
                            Text(
                              '8문제 이상 맞혀야\n캐릭터를 획득할 수 있어요!',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[700],
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              '열쇠가 반환되었습니다 🔑',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.amber[700],
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              
              const SizedBox(height: 40),
              
              // 버튼들
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HomeScreen(),
                      ),
                      (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 20,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: const Text('다시 시작'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
} 