import 'package:flutter/material.dart';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'home_screen.dart';
import 'collection_screen.dart';

// 캐릭터 정보 클래스
class CharacterInfo {
  final int id;
  final String koreanName;
  final String englishName;
  final String skill;
  final int combat;
  final int intelligence;
  final int cuteness;
  final int rarity;

  CharacterInfo({
    required this.id,
    required this.koreanName,
    required this.englishName,
    required this.skill,
    required this.combat,
    required this.intelligence,
    required this.cuteness,
    required this.rarity,
  });
}

// 캐릭터 데이터베이스
class CharacterDatabase {
  static final Map<String, CharacterInfo> _characters = {
    '가라마라라마라라만 단 마두둥둥 탁 툰퉁 퍼르쿤퉁': CharacterInfo(
      id: 1, koreanName: '가라마라라마라라만 단 마두둥둥 탁 툰퉁 퍼르쿤퉁',
      englishName: 'Garamararamaraman Dan Madudung Tak Tuntung Perrekuntung',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 3, cuteness: 5, rarity: 3
    ),
    '고릴로 워터멜론드릴로': CharacterInfo(
      id: 2, koreanName: '고릴로 워터멜론드릴로', englishName: 'Gorillo Watermelondrillo',
      skill: '수박 펀치 – 한방에 상대를 날려버림', combat: 4, intelligence: 3, cuteness: 2, rarity: 4
    ),
    '그라이푸시 메두시': CharacterInfo(
      id: 3, koreanName: '그라이푸시 메두시', englishName: 'Grapussy Medussy',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 2, cuteness: 5, rarity: 3
    ),
    '글로르보 프루토드릴로': CharacterInfo(
      id: 4, koreanName: '글로르보 프루토드릴로', englishName: 'Glorbo Frutodrillo',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 2, cuteness: 2, rarity: 3
    ),
    '라 바카 사투르노 사투르니타': CharacterInfo(
      id: 5, koreanName: '라 바카 사투르노 사투르니타', englishName: 'La Vacca Saturno Saturnita',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 2, cuteness: 4, rarity: 2
    ),
    '리노 토스트리노': CharacterInfo(
      id: 6, koreanName: '리노 토스트리노', englishName: 'Rino Tostrino',
      skill: '육중 바디 – 압도적 파워로 적을 밀어냄', combat: 4, intelligence: 2, cuteness: 3, rarity: 3
    ),
    '리릴리 라릴라': CharacterInfo(
      id: 7, koreanName: '리릴리 라릴라', englishName: 'Lirili Larila',
      skill: '시간 감속 – 일정 시간 적의 속도 느리게 함', combat: 4, intelligence: 4, cuteness: 3, rarity: 4
    ),
    '마카키니 바나니니': CharacterInfo(
      id: 8, koreanName: '마카키니 바나니니', englishName: 'Macachini Bananini',
      skill: '바나나 껍질 미끄럼 – 상대가 미끄러진다', combat: 3, intelligence: 3, cuteness: 4, rarity: 3
    ),
    '바나니타 돌피니타': CharacterInfo(
      id: 9, koreanName: '바나니타 돌피니타', englishName: 'Bananita Dolfinita',
      skill: '돌고래 점프 – 장애물을 뛰어넘음', combat: 3, intelligence: 4, cuteness: 5, rarity: 4
    ),
    '발레리나 카푸치나': CharacterInfo(
      id: 10, koreanName: '발레리나 카푸치나', englishName: 'Ballerina Cappuccina',
      skill: '포인테 리볼버 – 우아한 회전으로 상대 혼란', combat: 2, intelligence: 3, cuteness: 4, rarity: 4
    ),
    '발레리노 로로로': CharacterInfo(
      id: 11, koreanName: '발레리노 로로로', englishName: 'Ballerino Lorororo',
      skill: '육중 바디 – 압도적 파워로 적을 밀어냄', combat: 4, intelligence: 3, cuteness: 4, rarity: 4
    ),
    '보네카 암발라부': CharacterInfo(
      id: 12, koreanName: '보네카 암발라부', englishName: 'Boneca Ambalabu',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 2, cuteness: 5, rarity: 4
    ),
    '보브리토 반디토': CharacterInfo(
      id: 13, koreanName: '보브리토 반디토', englishName: 'Bovrito Bandito',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 3, cuteness: 2, rarity: 4
    ),
    '봄바르디로 크로코딜로': CharacterInfo(
      id: 14, koreanName: '봄바르디로 크로코딜로', englishName: 'Bombardiro Crocodilo',
      skill: '폭탄 모드 – 공중에서 공격 폭격을 가함', combat: 5, intelligence: 3, cuteness: 2, rarity: 5
    ),
    '봄봄비니 구지니': CharacterInfo(
      id: 15, koreanName: '봄봄비니 구지니', englishName: 'Bombombini Gujini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 4, cuteness: 3, rarity: 2
    ),
    '부르발로니 룰릴롤리': CharacterInfo(
      id: 16, koreanName: '부르발로니 룰릴롤리', englishName: 'Burballoni Rulilrolli',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 3, intelligence: 2, cuteness: 3, rarity: 3
    ),
    '브르르 브르르 파타핌': CharacterInfo(
      id: 17, koreanName: '브르르 브르르 파타핌', englishName: 'Brr Brr Patapim',
      skill: '브르르 파타임 – 모자에서 점프 공격', combat: 3, intelligence: 2, cuteness: 3, rarity: 3
    ),
    '브리 브리 비쿠스 디쿠스 봄비쿠스': CharacterInfo(
      id: 18, koreanName: '브리 브리 비쿠스 디쿠스 봄비쿠스', englishName: 'Bri Bri Vicus Dicus Bombicus',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 2, cuteness: 4, rarity: 3
    ),
    '블루베리니 옥토푸시니': CharacterInfo(
      id: 19, koreanName: '블루베리니 옥토푸시니', englishName: 'Blueberrini Octopussini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 5, cuteness: 3, rarity: 4
    ),
    '오 딘딘딘딘 둔 마 딘딘딘 둔': CharacterInfo(
      id: 20, koreanName: '오 딘딘딘딘 둔 마 딘딘딘 둔', englishName: 'O Dindindindin Dun Ma Dindindin Dun',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 3, intelligence: 4, cuteness: 5, rarity: 4
    ),
    '오랑구티니 아나나시니': CharacterInfo(
      id: 21, koreanName: '오랑구티니 아나나시니', englishName: 'Orangutini Ananassini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 3, cuteness: 2, rarity: 4
    ),
    '일 칵토 히포포타모': CharacterInfo(
      id: 22, koreanName: '일 칵토 히포포타모', englishName: 'Il Cacto Hippopotamo',
      skill: '육중 바디 – 압도적 파워로 적을 밀어냄', combat: 5, intelligence: 3, cuteness: 4, rarity: 4
    ),
    '지라파 첼레스테': CharacterInfo(
      id: 23, koreanName: '지라파 첼레스테', englishName: 'Giraffa Celeste',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 3, cuteness: 4, rarity: 3
    ),
    '지브라 주브라 지브라리니': CharacterInfo(
      id: 24, koreanName: '지브라 주브라 지브라리니', englishName: 'Zebra Jubra Zebrarini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 3, cuteness: 3, rarity: 4
    ),
    '침판지니 바나니니': CharacterInfo(
      id: 25, koreanName: '침판지니 바나니니', englishName: 'Chimpanzini Bananini',
      skill: '바나나 폭탄 – 직접 던지는 바나나 공격', combat: 3, intelligence: 2, cuteness: 4, rarity: 4
    ),
    '카푸치노 아사시노': CharacterInfo(
      id: 26, koreanName: '카푸치노 아사시노', englishName: 'Cappuccino Assassino',
      skill: '카페향 – 주변을 힐링', combat: 2, intelligence: 4, cuteness: 5, rarity: 4
    ),
    '코코판토 엘레판토': CharacterInfo(
      id: 27, koreanName: '코코판토 엘레판토', englishName: 'Cocopanto Elephanto',
      skill: '육중 바디 – 압도적 파워로 적을 밀어냄', combat: 4, intelligence: 3, cuteness: 3, rarity: 4
    ),
    '크로코딜도 페니시니': CharacterInfo(
      id: 28, koreanName: '크로코딜도 페니시니', englishName: 'Crocodildo Penisini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 3, cuteness: 5, rarity: 3
    ),
    '타 타 타 타 타 타 타 타 타 타 타 사후르': CharacterInfo(
      id: 29, koreanName: '타 타 타 타 타 타 타 타 타 타 타 사후르', englishName: 'Ta Ta Ta Ta Ta Ta Ta Ta Ta Ta Ta Sahur',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 3, intelligence: 3, cuteness: 3, rarity: 5
    ),
    '퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 사후르': CharacterInfo(
      id: 30, koreanName: '퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 사후르', englishName: 'Tung Tung Tung Tung Tung Tung Tung Tung Tung Sahur',
      skill: '사후르 리듬 – 리듬에 맞춰 충격파를 발사', combat: 5, intelligence: 2, cuteness: 4, rarity: 4
    ),
    '트랄랄레로 트랄랄라': CharacterInfo(
      id: 31, koreanName: '트랄랄레로 트랄랄라', englishName: 'Tralalero Tralala',
      skill: '스니커즈 스프린트 – 물 위도 달릴 수 있는 속도로 적을 추격', combat: 4, intelligence: 4, cuteness: 3, rarity: 4
    ),
    '트래코투코툴루 델라펠라두스투즈': CharacterInfo(
      id: 32, koreanName: '트래코투코툴루 델라펠라두스투즈', englishName: 'Tracotucotulu Dellapelladustuz',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 2, cuteness: 4, rarity: 5
    ),
    '트룰리메로 트룰리치나': CharacterInfo(
      id: 33, koreanName: '트룰리메로 트룰리치나', englishName: 'Trullimero Trullichina',
      skill: '트룰리 춤 – 리듬 공격', combat: 3, intelligence: 3, cuteness: 4, rarity: 4
    ),
    '트리피 트로피1': CharacterInfo(
      id: 34, koreanName: '트리피 트로피1', englishName: 'Trippi Troppi 1',
      skill: '해저 충격파 – 바다에서 폭발하는 충격', combat: 3, intelligence: 2, cuteness: 4, rarity: 3
    ),
    '트리피 트로피2': CharacterInfo(
      id: 35, koreanName: '트리피 트로피2', englishName: 'Trippi Troppi 2',
      skill: '해저 충격파 – 바다에서 폭발하는 충격', combat: 3, intelligence: 2, cuteness: 4, rarity: 3
    ),
    '트릭 트랙 바라붐': CharacterInfo(
      id: 36, koreanName: '트릭 트랙 바라붐', englishName: 'Trick Track Baraboom',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 4, cuteness: 2, rarity: 4
    ),
    '티그룰리 그레이프루투니': CharacterInfo(
      id: 37, koreanName: '티그룰리 그레이프루투니', englishName: 'Tigruli GrapeFruitini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 4, cuteness: 5, rarity: 5
    ),
    '티그룰리니 워터멜리니': CharacterInfo(
      id: 38, koreanName: '티그룰리니 워터멜리니', englishName: 'Tigrulini Watermelini',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 5, intelligence: 2, cuteness: 2, rarity: 4
    ),
    '팟 핫스팟': CharacterInfo(
      id: 39, koreanName: '팟 핫스팟', englishName: 'Pot Hotspot',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 2, intelligence: 5, cuteness: 2, rarity: 5
    ),
    '프룰리 프룰라': CharacterInfo(
      id: 40, koreanName: '프룰리 프룰라', englishName: 'Frulli Frulla',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 4, cuteness: 5, rarity: 2
    ),
    '프리고 카멜로': CharacterInfo(
      id: 41, koreanName: '프리고 카멜로', englishName: 'Frigo Camello',
      skill: '뇌절 임팩트 – 예측불가 기습공격', combat: 4, intelligence: 2, cuteness: 3, rarity: 3
    ),
  };

  static CharacterInfo? getCharacterInfo(String koreanName) {
    return _characters[koreanName];
  }
}

class RewardScreen extends StatefulWidget {
  final int score;
  final VoidCallback? onRefundKey;
  
  const RewardScreen({Key? key, required this.score, this.onRefundKey}) : super(key: key);

  @override
  State<RewardScreen> createState() => _RewardScreenState();
}

class _RewardScreenState extends State<RewardScreen> {
  String selectedImage = '';
  bool hasEarnedCharacter = false;
  CharacterInfo? selectedCharacterInfo;
  
  // brainrot_image 폴더의 이미지 파일들
  final List<String> rewardImages = [
    'brainrot_image/가라마라라마라라만 단 마두둥둥 탁 툰퉁 퍼르쿤퉁.webp',
    'brainrot_image/고릴로 워터멜론드릴로.webp',
    'brainrot_image/그라이푸시 메두시.webp',
    'brainrot_image/글로르보 프루토드릴로.webp',
    'brainrot_image/라 바카 사투르노 사투르니타.webp',
    'brainrot_image/리노 토스트리노.webp',
    'brainrot_image/리릴리 라릴라.webp',
    'brainrot_image/마카키니 바나니니.webp',
    'brainrot_image/바나니타 돌피니타.webp',
    'brainrot_image/발레리나 카푸치나.webp',
    'brainrot_image/발레리노 로로로.webp',
    'brainrot_image/보네카 암발라부.webp',
    'brainrot_image/보브리토 반디토.webp',
    'brainrot_image/봄바르디로 크로코딜로.webp',
    'brainrot_image/봄봄비니 구지니.webp',
    'brainrot_image/부르발로니 룰릴롤리.webp',
    'brainrot_image/브르르 브르르 파타핌.webp',
    'brainrot_image/브리 브리 비쿠스 디쿠스 봄비쿠스.webp',
    'brainrot_image/블루베리니 옥토푸시니.webp',
    'brainrot_image/오 딘딘딘딘 둔 마 딘딘딘 둔.webp',
    'brainrot_image/오랑구티니 아나나시니.webp',
    'brainrot_image/일 칵토 히포포타모.webp',
    'brainrot_image/지라파 첼레스테.webp',
    'brainrot_image/지브라 주브라 지브라리니.webp',
    'brainrot_image/침판지니 바나니니.webp',
    'brainrot_image/카푸치노 아사시노.webp',
    'brainrot_image/코코판토 엘레판토.webp',
    'brainrot_image/크로코딜도 페니시니.webp',
    'brainrot_image/타 타 타 타 타 타 타 타 타 타 타 사후르.webp',
    'brainrot_image/퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 퉁 사후르.webp',
    'brainrot_image/트랄랄레로 트랄랄라.webp',
    'brainrot_image/트래코투코툴루 델라펠라두스투즈.webp',
    'brainrot_image/트룰리메로 트룰리치나.webp',
    'brainrot_image/트리피 트로피1.webp',
    'brainrot_image/트리피 트로피2.webp',
    'brainrot_image/트릭 트랙 바라붐.webp',
    'brainrot_image/티그룰리 그레이프루투니.webp',
    'brainrot_image/티그룰리니 워터멜리니.webp',
    'brainrot_image/팟 핫스팟.webp',
    'brainrot_image/프룰리 프룰라.webp',
    'brainrot_image/프리고 카멜로.webp',
  ];

  @override
  void initState() {
    super.initState();
    hasEarnedCharacter = widget.score >= 8;
    if (hasEarnedCharacter) {
      selectRandomImage();
      saveCharacterToCollection();
    } else {
      // 8점 미만일 때 열쇠 반환
      widget.onRefundKey?.call();
    }
  }

  void selectRandomImage() {
    final random = Random();
    setState(() {
      selectedImage = rewardImages[random.nextInt(rewardImages.length)];
      String characterName = getCharacterName(selectedImage);
      selectedCharacterInfo = CharacterDatabase.getCharacterInfo(characterName);
    });
  }

  Future<void> saveCharacterToCollection() async {
    if (selectedImage.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      List<String> collectedCharacters = prefs.getStringList('collected_characters') ?? [];
      
      if (!collectedCharacters.contains(selectedImage)) {
        collectedCharacters.add(selectedImage);
        await prefs.setStringList('collected_characters', collectedCharacters);
      }
    }
  }

  String getCharacterName(String imagePath) {
    return imagePath
        .split('/')
        .last
        .replaceAll('.webp', '')
        .replaceAll('brainrot_image/', '');
  }

  // 별 표시 위젯 (채워진 별만 표시)
  Widget buildStarsWidget(int rating) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(rating, (index) {
        return const Icon(
          Icons.star,
          color: Colors.amber,
          size: 18,
        );
      }),
    );
  }

  String getGradeText() {
    if (widget.score == 10) {
      return '완벽해요! 🌟';
    } else if (widget.score >= 8) {
      return '훌륭해요! 🎉';
    } else if (widget.score >= 6) {
      return '잘했어요! 👏';
    } else if (widget.score >= 4) {
      return '좋아요! 😊';
    } else {
      return '다시 도전해봐요! 💪';
    }
  }

  Color getGradeColor() {
    if (widget.score == 10) {
      return Colors.amber;
    } else if (widget.score >= 8) {
      return Colors.green;
    } else if (widget.score >= 6) {
      return Colors.blue;
    } else if (widget.score >= 4) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }

  Widget _buildDefaultRewardImage() {
    return Container(
      width: 300,
      height: 300,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.emoji_events,
            size: 80,
            color: Colors.amber[600],
          ),
          const SizedBox(height: 10),
          Text(
            '축하합니다!',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[50],
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              // 축하 메시지
              Container(
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      '게임 완료!',
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: Colors.pink[800],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '점수: ${widget.score}/10',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: getGradeColor(),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      getGradeText(),
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: getGradeColor(),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // 보상 영역
              Container(
                padding: const EdgeInsets.all(20),
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      hasEarnedCharacter ? '새로운 캐릭터 획득!' : '캐릭터 획득 실패',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                        color: hasEarnedCharacter ? Colors.amber[800] : Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 15),
                    
                    if (hasEarnedCharacter && selectedImage.isNotEmpty) ...[
                      // 캐릭터 이름
                      Text(
                        getCharacterName(selectedImage),
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.pink[800],
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 15),
                      
                      // 캐릭터 이미지
                      ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: Image.asset(
                          selectedImage,
                          width: 300,
                          height: 300,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return _buildDefaultRewardImage();
                          },
                        ),
                      ),
                      
                      // 캐릭터 상세 정보
                      if (selectedCharacterInfo != null) ...[
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            color: Colors.pink[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.pink[200]!),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '📊 캐릭터 정보',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Colors.pink[800],
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 12),
                              
                              // 영어 이름
                              Text(
                                '영어 이름: ${selectedCharacterInfo!.englishName}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                              const SizedBox(height: 8),
                              
                              // 능력치들
                              Row(
                                children: [
                                  const Text('🥊 전투력: ', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                  buildStarsWidget(selectedCharacterInfo!.combat),
                                ],
                              ),
                              const SizedBox(height: 6),
                              
                              Row(
                                children: [
                                  const Text('🧠 지능: ', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                  buildStarsWidget(selectedCharacterInfo!.intelligence),
                                ],
                              ),
                              const SizedBox(height: 6),
                              
                              Row(
                                children: [
                                  const Text('💖 귀여움: ', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                  buildStarsWidget(selectedCharacterInfo!.cuteness),
                                ],
                              ),
                              const SizedBox(height: 6),
                              
                              Row(
                                children: [
                                  const Text('💎 희귀도: ', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                  buildStarsWidget(selectedCharacterInfo!.rarity),
                                ],
                              ),
                              const SizedBox(height: 12),
                              
                              // 특수 스킬
                              Text(
                                '⚡ 특수 스킬:',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.purple[700],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.purple[50],
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.purple[200]!),
                                ),
                                child: Text(
                                  selectedCharacterInfo!.skill,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.purple[800],
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ] else ...[
                      // 캐릭터 획득 실패 시
                      Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(
                            color: Colors.grey[400]!,
                            style: BorderStyle.solid,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.lock,
                              size: 80,
                              color: Colors.grey[600],
                            ),
                            const SizedBox(height: 20),
                            Text(
                              '8문제 이상 맞혀야\n캐릭터를 획득할 수 있어요!',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey[700],
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              '열쇠가 반환되었습니다 🔑',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.amber[700],
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              
              const SizedBox(height: 40),
              
              // 버튼들
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HomeScreen(),
                      ),
                      (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 20,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                  child: const Text('다시 시작'),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
  }
} 